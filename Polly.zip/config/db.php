<?php

return [
    'host' => 'db',        // имя сервиса из docker-compose
    'port' => 3306,
    'dbname' => 'game_balance',
    'user' => 'game_user',
    'password' => 'game_password',
    'charset' => 'utf8mb4',
];
