document.addEventListener('DOMContentLoaded', () => {
    const loginButton = document.getElementById('loginButton');
    const logoutButton = document.getElementById('logoutButton');
    const userInfo = document.getElementById('userInfo');

    const pollHeader = document.getElementById('pollHeader');
    const pollResults = document.getElementById('pollResults');
    const voteSection = document.getElementById('voteSection');
    const manageSection = document.getElementById('manageSection');


    function getPollStatus(poll) {
    // 1) is_active: true/false
    if (typeof poll.is_active === 'boolean') {
        return {
            text: poll.is_active ? 'active' : 'closed',
            isClosed: !poll.is_active
        };
    }

    // 2) is_closed: true/false или 0/1
    if (poll.is_closed !== undefined) {
        const closed = !!poll.is_closed;
        return {
            text: closed ? 'closed' : 'active',
            isClosed: closed
        };
    }

    // 3) строковый статус
    if (typeof poll.status === 'string') {
        return {
            text: poll.status,
            isClosed: poll.status !== 'active'
        };
    }

    // Фоллбек
    return {
        text: 'unknown',
        isClosed: false
    };
}


    const currentUser = getCurrentUser();
    if (currentUser) {
        loginButton.style.display = 'none';
        logoutButton.style.display = 'inline-block';
        userInfo.style.display = 'inline-block';
        userInfo.textContent = currentUser.username;
    } else {
        loginButton.style.display = 'inline-block';
        logoutButton.style.display = 'none';
        userInfo.style.display = 'none';
    }

    loginButton.addEventListener('click', () => {
        window.location.href = 'auth.html';
    });

    logoutButton.addEventListener('click', () => {
        clearAuth();
        window.location.reload();
    });

    const params = new URLSearchParams(window.location.search);
    const pollId = params.get('id');

    if (!pollId) {
        pollHeader.innerHTML = '<p>Poll id is missing</p>';
        return;
    }

    loadPoll();

    async function loadPoll() {
        try {
            const poll = await apiGetPoll(pollId);
            const status = getPollStatus(poll);

            pollHeader.innerHTML = `
                <h1>${poll.title ?? '(no title)'}</h1>
                <p>${poll.description ?? ''}</p>
                <p class="poll-meta">
                    Status: <strong>${status.text}</strong><br>
                    Created at: ${poll.created_at ?? ''}
                </p>
            `;

            await loadResults(poll);
        } catch (err) {
            console.error(err);
            pollHeader.innerHTML = `<p>Error loading poll: ${err.message}</p>`;
        }
    }

    async function loadResults(poll) {
        pollResults.innerHTML = '<p>Loading results...</p>';
        try {
            const data = await apiGetPollResults(pollId);
            const { options, user_vote_option_id } = data;

            
            let html = '<h2>Results</h2><ul class="option-list">';
            options.forEach(opt => {
                const label =
                    opt.text ??
                    opt.label ??
                    opt.label_key ??               // на всякий случай, если вдруг так
                    `Option #${opt.id}`;
            
                const votes =
                    opt.votes ??
                    opt.votes_count ??
                    opt.total_votes ??
                    0;
            
                html += `
                    <li>
                        <strong>${label}</strong>
                        — ${votes} votes
                        ${user_vote_option_id === opt.id ? ' <span class="tag">Your vote</span>' : ''}
                    </li>
                `;
            });
            html += '</ul>';
            pollResults.innerHTML = html;

            renderVoteForm(options, user_vote_option_id, poll);
            renderManageSection(poll);

        } catch (err) {
            console.error(err);
            pollResults.innerHTML = `<p>Error loading results: ${err.message}</p>`;
        }
    }

    function renderVoteForm(options, user_vote_option_id, poll) {
        voteSection.innerHTML = '';
        const currentUser = getCurrentUser();

        if (!currentUser) {
            voteSection.innerHTML = '<p>You must log in to vote.</p>';
            return;
        }

        if (poll.status !== 'active') {
            voteSection.innerHTML = '<p>This poll is closed.</p>';
            return;
        }

        const form = document.createElement('form');
        form.innerHTML = `
            <h2>Vote</h2>
            ${options.map(opt => `
                <label class="radio-option">
                    <input type="radio" name="option" value="${opt.id}"
                        ${user_vote_option_id === opt.id ? 'checked' : ''}>
                    <span>${opt.label_key}</span>
                </label>
            `).join('')}
            <button type="submit" class="btn btn-primary">
                Submit vote
            </button>
            <p id="voteMessage" class="message"></p>
        `;

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            const optionId = formData.get('option');

            if (!optionId) {
                document.getElementById('voteMessage').textContent = 'Please select an option.';
                return;
            }

            try {
                document.getElementById('voteMessage').textContent = 'Sending vote...';
                await apiCastVote(pollId, Number(optionId));
                document.getElementById('voteMessage').textContent = 'Vote accepted.';
                await loadResults(poll);
            } catch (err) {
                document.getElementById('voteMessage').textContent = `Error: ${err.message}`;
            }
        });

        voteSection.appendChild(form);
    }

    function renderManageSection(poll) {
        manageSection.innerHTML = '';
        const currentUser = getCurrentUser();
        if (!currentUser) return;

        if (poll.created_by !== currentUser.id) {
            return;
        }

        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
            <h2>Manage poll</h2>
            <button id="closePollBtn" class="btn btn-secondary">
                ${poll.status === 'active' ? 'Close poll' : 'Open poll'}
            </button>
            <button id="deletePollBtn" class="btn btn-danger">Delete poll</button>
            <!-- Кнопка Edit можно добавить позже -->
        `;
        manageSection.appendChild(wrapper);

        const closeBtn = document.getElementById('closePollBtn');
        const deleteBtn = document.getElementById('deletePollBtn');

        closeBtn.addEventListener('click', async () => {
            try {
                if (poll.status === 'active') {
                    await apiClosePoll(poll.id);
                } else {
                    await apiOpenPoll(poll.id);
                }
                await loadPoll();
            } catch (err) {
                alert('Error changing poll status: ' + err.message);
            }
        });

        deleteBtn.addEventListener('click', async () => {
            if (!confirm('Delete this poll?')) return;
            try {
                await apiDeletePoll(poll.id);
                window.location.href = 'index.html';
            } catch (err) {
                alert('Error deleting poll: ' + err.message);
            }
        });
    }
});
