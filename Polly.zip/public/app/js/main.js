document.addEventListener('DOMContentLoaded', () => {
    const loginButton = document.getElementById('loginButton');
    const logoutButton = document.getElementById('logoutButton');
    const userInfo = document.getElementById('userInfo');
    const createPollButton = document.getElementById('createPollButton');
    const pollList = document.getElementById('pollList');

    const currentUser = getCurrentUser();

    if (currentUser) {
        loginButton.style.display = 'none';
        logoutButton.style.display = 'inline-block';
        userInfo.style.display = 'inline-block';
        userInfo.textContent = currentUser.username;
        createPollButton.style.display = 'inline-block';
    } else {
        loginButton.style.display = 'inline-block';
        logoutButton.style.display = 'none';
        userInfo.style.display = 'none';
        createPollButton.style.display = 'none';
    }

    loginButton.addEventListener('click', () => {
        window.location.href = 'auth.html';
    });

    logoutButton.addEventListener('click', () => {
        clearAuth();
        window.location.reload();
    });

    createPollButton.addEventListener('click', () => {
 
        alert('Create poll UI is not implemented yet 🙂');
    });


    function getPollStatus(poll) {
    // 1) is_active: true/false
    if (typeof poll.is_active === 'boolean') {
        return {
            text: poll.is_active ? 'active' : 'closed',
            isClosed: !poll.is_active
        };
    }

    // 2) is_closed: true/false или 0/1
    if (poll.is_closed !== undefined) {
        const closed = !!poll.is_closed;
        return {
            text: closed ? 'closed' : 'active',
            isClosed: closed
        };
    }

    // 3) строковый статус
    if (typeof poll.status === 'string') {
        return {
            text: poll.status,
            isClosed: poll.status !== 'active'
        };
    }

    // Фоллбек
    return {
        text: 'unknown',
        isClosed: false
    };
}


    loadPolls();

    async function loadPolls() {
        pollList.innerHTML = '<p>Loading polls...</p>';
        try {
            const polls = await apiGetPolls();
            if (!polls || polls.length === 0) {
                pollList.innerHTML = '<p>No polls yet.</p>';
                return;
            }

            pollList.innerHTML = '';
            polls.forEach(poll => {
                const card = document.createElement('article');
                card.className = 'poll-card';
                const status = getPollStatus(poll);
                card.innerHTML = `
                    <h2>${poll.title ?? '(no title)'}</h2>
                    <p>${poll.description ?? ''}</p>
                    <p class="poll-meta">
                        Status: <strong>${status.text}</strong><br>
                        Created at: ${poll.created_at ?? ''}
                    </p>
                    <button class="btn btn-primary" data-id="${poll.id}">
                        Open poll
                    </button>
                `;

                pollList.appendChild(card);
            });

            pollList.addEventListener('click', (e) => {
                const btn = e.target.closest('button[data-id]');
                if (!btn) return;
                const pollId = btn.getAttribute('data-id');
                window.location.href = `poll.html?id=${encodeURIComponent(pollId)}`;
            });

        } catch (err) {
            console.error(err);
            pollList.innerHTML = `<p>Error loading polls: ${err.message}</p>`;
        }
    }
}
);
